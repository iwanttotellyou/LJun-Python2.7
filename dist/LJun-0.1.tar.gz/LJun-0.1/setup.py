from distutils.core import setup

setup(
    name='LJun',
    version='0.1',
    py_modules=['LJun/__init__', 'LJun/Lprint'],
    author='LJun'
)
